#!/bin/bash
uniq -u