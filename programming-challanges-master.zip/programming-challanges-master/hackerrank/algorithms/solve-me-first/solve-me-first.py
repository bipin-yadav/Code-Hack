#!/usr/bin/env python

import sys


if __name__ == '__main__':
    A = int(sys.stdin.readline())
    B = int(sys.stdin.readline())
    print(A + B)