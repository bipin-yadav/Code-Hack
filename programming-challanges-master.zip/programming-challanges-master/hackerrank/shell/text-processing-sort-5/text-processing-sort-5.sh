#!/bin/bash

sort -nr -t$'\t' -k2