from __future__ import print_function

print('Primitive : double')
print('Primitive : char')
print('Primitive : boolean')
print('Primitive : int')
print('Referenced : String')
print('Primitive : boolean')
print('Primitive : double')
print('Primitive : char')
print('Referenced : String')
