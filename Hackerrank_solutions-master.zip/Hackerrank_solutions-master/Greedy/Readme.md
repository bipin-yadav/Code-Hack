#Greedy

This folder contains the solutions to the questions in the greedy subdomain.
