#!/bin/bash

cut -d' ' -f-3