#!/bin/bash

sort -nr -t'|' -k2