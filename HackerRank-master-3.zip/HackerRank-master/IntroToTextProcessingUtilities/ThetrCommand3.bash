#!/bin/bash
tr -s [:space:]