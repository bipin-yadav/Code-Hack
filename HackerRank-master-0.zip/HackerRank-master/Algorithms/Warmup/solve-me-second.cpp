//solve-me-second.cpp
//Solve me second
//Author: derekhh
//Jun 12, 2015

#include <iostream>
using namespace std;

int main()
{
	int t;
	cin >> t;
	while (t--)
	{
		int a, b;
		cin >> a >> b;
		cout << a + b << endl;
	}
	return 0;
}