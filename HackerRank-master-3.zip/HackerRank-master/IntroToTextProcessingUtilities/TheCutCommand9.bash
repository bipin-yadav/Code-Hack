#!/bin/bash
cut -d $'\t' -f2-