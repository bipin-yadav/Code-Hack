/*******************************************************
 * Copyright (C) 2015 Haotian Wu
 * 
 * This file is the solution to the question:
 * https://www.hackerrank.com/challenges/maximizing-xor
 * 
 * Redistribution and use in source and binary forms are permitted.
 *******************************************************/
#include <map>
#include <set>
#include <list>
#include <cmath>
#include <ctime>
#include <deque>
#include <queue>
#include <stack>
#include <bitset>
#include <cstdio>
#include <limits>
#include <vector>
#include <cstdlib>
#include <numeric>
#include <sstream>
#include <iostream>
#include <algorithm>
using namespace std;
/*
 * Complete the function below.
 */
int maxXor(int l, int r) {
    // Very straight forward. But watch out the parenthesis in (i^j)>mm ! Very important!
    int mm=0;
    for (int i=l;i<=r;i++)
        for (int j=l;j<=r;j++)
            if ((i^j)>mm)
                mm = i^j;
    return mm;
}

int main() {
    int res;
    int _l;
    cin >> _l;
    
    int _r;
    cin >> _r;
    
    res = maxXor(_l, _r);
    cout << res;
    
    return 0;
}
