# Day 0

## Problem Statement

Welcome to Day 0 and the wonderful world of coding! Check out the video tutorial here, or just jump right into the problem. The tutorial is based on Java, but you can submit your solution in other popular languages.

For this challenge, all you have to do is print the following two lines:
```
Hello World.
Welcome to 30 Days of Code.
```
