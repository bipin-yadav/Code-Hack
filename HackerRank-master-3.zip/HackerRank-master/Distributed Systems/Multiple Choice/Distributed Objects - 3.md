____  is a framework for distributed components using a messaging paradigm.


1. CORBA

2. DCOM

3. DDObjects

4. **Jt**