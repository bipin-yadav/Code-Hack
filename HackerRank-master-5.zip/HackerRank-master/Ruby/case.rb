# https://www.hackerrank.com/challenges/ruby-case

def identify_class(obj)
  case obj.class.name
  when "Hacker"
    puts "It's a Hacker!"
  when "Submission"
    puts "It's a Submission!"
  when "TestCase"
    puts "It's a TestCase!"
  when "Contest"
    puts "It's a Contest!"
  else
    puts "It's an unknown mode!"
  end
end
