#!/bin/bash

cut -d' ' -f4