class Arithmetic {
  public static Integer add(Integer x, Integer y) { return x + y; }
}

class Adder extends Arithmetic {}
