//tree-pruning.cpp
//Tree Pruning
//Weekly Challenges - Week 11
//Author: derekhh

#include<iostream>
using namespace std;

int w[100000];

int main()
{
	int n, k;
	cin >> n >> k;
	for (int i = 0; i < n; i++)
		cin >> w[i];
	for (int i = 0; i < n - 1; i++)
	{
		int a, b;
	}
	return 0;
}