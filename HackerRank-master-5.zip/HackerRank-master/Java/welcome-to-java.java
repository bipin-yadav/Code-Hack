// https://www.hackerrank.com/challenges/welcome-to-java

public class Solution {
    public static void main(String []argh) {
        System.out.println("Hello World.");
        System.out.println("Hello Java.");
    }
}
