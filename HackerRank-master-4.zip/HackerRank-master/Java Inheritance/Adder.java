//Write your code here
//Write your code here

class Adder extends Arithmetic{
    
    Adder() {
      super();
    }
    
    public int add(int a, int b) {
        int sum;
        sum = a + b;
        return sum;
    }
}

class Arithmetic {
    Arithmetic() {
    }
}

