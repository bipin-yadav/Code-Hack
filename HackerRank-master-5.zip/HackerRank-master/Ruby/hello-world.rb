# https://www.hackerrank.com/challenges/ruby-hello-world

print "Hello HackerRank!!"
