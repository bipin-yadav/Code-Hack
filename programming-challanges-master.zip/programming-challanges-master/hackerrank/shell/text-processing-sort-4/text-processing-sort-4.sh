#!/bin/bash

sort -nr