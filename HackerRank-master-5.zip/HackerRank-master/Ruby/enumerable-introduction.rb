# https://www.hackerrank.com/challenges/ruby-enumerable-introduction

def iterate_colors(colors)
  arr = []
  colors.each do |color|
    arr.push(color)
  end
  arr
end

