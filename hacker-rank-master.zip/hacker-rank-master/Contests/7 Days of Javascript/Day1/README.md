# Day 1: Print The Input

## Task

Use what you learned in the previous challenge to complete the processData function by printing the input parameter to the console.

## Input Format

The first and only line of input contains a string.

## Constraints
```
String length ≤500
```
Output Format

Print input to the console.

## Sample Input
```
How many chickens does it take to cross the road?
```
## Sample Output
```
How many chickens does it take to cross the road?
```
