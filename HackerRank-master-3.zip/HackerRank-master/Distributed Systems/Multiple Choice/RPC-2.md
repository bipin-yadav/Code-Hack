RPC works between two processes. These processes may be:

1. on the same computer

2. on different computers connected with a network

3. **both (a) and (b)**

4. none of the mentioned

