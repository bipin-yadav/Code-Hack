#!/bin/bash
# https://www.hackerrank.com/challenges/text-processing-in-linux-the-grep-command-2

grep $1 -iw 'the'

exit 0
