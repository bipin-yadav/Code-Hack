from __future__ import print_function
import sys

def day_0():
    print("Hello World.\nWelcome to 30 Days of Code.")

def main():
    day_0()

if __name__ == '__main__':
    main()
