# https://www.hackerrank.com/challenges/ruby-until

until coder.oh_one?
  coder.practice
end
