If there are M partitions of the input, there are M map workers running simultaneously. True or False?

1. True

2. **False**