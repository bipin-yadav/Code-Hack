hello_world = putStrLn "Hello World"

main = do
    hello_world
