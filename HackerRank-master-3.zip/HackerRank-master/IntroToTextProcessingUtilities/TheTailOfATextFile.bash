#!/bin/bash
tail -n 20