HackerRank Challenges
=====================

My solutions in Python to the challenges posted on [HackerRank](http://www.hackerrank.com).

Unless otherwise specified, all solutions are written for Python 3.x and have passed all test cases / have an optimal (or nearly optimal) score.