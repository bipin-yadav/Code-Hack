#!/bin/bash
# https://www.hackerrank.com/challenges/text-processing-in-linux-the-grep-command-3

grep $1 -viw 'that'

exit 0

