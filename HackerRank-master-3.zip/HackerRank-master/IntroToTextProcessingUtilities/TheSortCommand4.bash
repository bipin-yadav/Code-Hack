#!/bin/bash
sort -n -r