____ is a framework for distributed objects using Borland Delphi.

1. CORBA

2. DCOM

3. **DDObjects**

4. Jt