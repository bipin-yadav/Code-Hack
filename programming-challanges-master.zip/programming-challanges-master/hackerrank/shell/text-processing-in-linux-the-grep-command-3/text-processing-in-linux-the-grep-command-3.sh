#!/bin/bash

grep -vwi that