#!/bin/bash
cut -d ' ' -f1,2,3