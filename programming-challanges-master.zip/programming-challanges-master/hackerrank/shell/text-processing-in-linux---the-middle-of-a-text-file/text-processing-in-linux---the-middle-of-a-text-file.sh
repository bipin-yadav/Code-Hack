#!/bin/bash

head -n22 | tail -n11