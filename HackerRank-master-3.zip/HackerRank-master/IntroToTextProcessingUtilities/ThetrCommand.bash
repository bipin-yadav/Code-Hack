#!/bin/bash
tr "(" "[" | tr ")" "]"