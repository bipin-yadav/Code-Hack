//solve-me-first.cpp
//Solve me first
//Author: derekhh

#include<iostream>
using namespace std;

int main()
{
	int a, b;
	cin >> a >> b;
	cout << a + b << endl;
	return 0;
}