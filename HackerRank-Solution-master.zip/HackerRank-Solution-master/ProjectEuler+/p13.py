s = 0
for i in xrange(input()):
	s += input()
print str(s)[:10]