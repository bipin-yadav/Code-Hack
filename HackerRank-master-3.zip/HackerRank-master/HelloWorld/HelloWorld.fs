﻿[<EntryPoint>]
let main args = 
    printfn "Hello World"
    0