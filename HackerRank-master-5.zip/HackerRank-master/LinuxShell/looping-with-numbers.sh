#!/bin/bash

# https://www.hackerrank.com/challenges/bash-tutorials---looping-with-numbers

for i in {1..50}
do
  echo "$i"
done
