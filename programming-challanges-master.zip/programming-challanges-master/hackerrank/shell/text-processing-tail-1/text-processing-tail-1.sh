#!/bin/bash

tail -n20