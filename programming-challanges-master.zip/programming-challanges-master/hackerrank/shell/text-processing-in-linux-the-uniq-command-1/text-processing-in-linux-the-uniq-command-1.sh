#!/bin/bash

uniq