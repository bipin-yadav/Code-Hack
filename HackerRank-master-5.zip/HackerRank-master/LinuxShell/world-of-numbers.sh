#!/bin/bash

# https://www.hackerrank.com/challenges/bash-tutorials---the-world-of-numbers

read a
read b

echo $(($a + $b))
echo $(($a - $b))
echo $(($a * $b))
echo $(($a / $b))

