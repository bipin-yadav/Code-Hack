#!/bin/bash

read name
echo "Welcome ${name}"