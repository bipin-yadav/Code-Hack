#!/bin/bash

cut -f2-