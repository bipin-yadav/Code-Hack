#!/bin/bash

grep -wi the