An RPC (remote procedure call) is initiated by the:

1. server

2. **client**

3. both (a) and (b)

4. neither (a) nor (b)