// https://www.hackerrank.com/challenges/c-tutorial-basic-data-types

#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    string s;
    for(int i=0; i < 6; i++) {
        cin >> s;
        cout << s << endl;
    }
    
    return 0;
}

