#!/usr/bin/env python

import math, sys


if __name__ == '__main__':
    N = int(sys.stdin.readline())
    print(math.factorial(N))