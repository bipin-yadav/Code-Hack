#!/bin/bash

tr -s ' ' ' '