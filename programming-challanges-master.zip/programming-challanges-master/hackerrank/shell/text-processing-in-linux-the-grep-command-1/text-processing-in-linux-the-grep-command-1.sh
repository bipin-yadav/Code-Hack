#!/bin/bash

grep -w the