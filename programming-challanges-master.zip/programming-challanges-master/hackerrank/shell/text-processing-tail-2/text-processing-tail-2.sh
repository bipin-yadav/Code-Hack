#!/bin/bash

tail -c20