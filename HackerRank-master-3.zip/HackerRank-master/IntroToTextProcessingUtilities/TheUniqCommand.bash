#!/bin/bash
uniq