#!/bin/bash

head -n20