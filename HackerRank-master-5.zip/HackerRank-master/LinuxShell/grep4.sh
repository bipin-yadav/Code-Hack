#!/bin/bash
# https://www.hackerrank.com/challenges/text-processing-in-linux-the-grep-command-4

grep $1 -iw 'the\|that\|then\|those'

exit 0


