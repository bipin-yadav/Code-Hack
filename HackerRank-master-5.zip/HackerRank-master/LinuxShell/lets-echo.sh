#!/bin/bash

# https://www.hackerrank.com/challenges/bash-tutorials-lets-echo

echo "HELLO"
