#!/bin/bash

cut -f-3