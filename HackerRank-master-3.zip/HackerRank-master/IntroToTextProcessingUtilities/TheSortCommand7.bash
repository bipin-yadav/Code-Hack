#!/bin/bash
sort -k2,2 -t '|' -n -r