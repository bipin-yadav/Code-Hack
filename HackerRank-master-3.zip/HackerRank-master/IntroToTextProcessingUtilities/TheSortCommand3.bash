#!/bin/bash
sort -n