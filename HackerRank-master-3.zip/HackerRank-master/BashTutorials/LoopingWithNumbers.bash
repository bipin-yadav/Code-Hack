#!/bin/bash
X=1
while [ $X -le 50 ]
do
	echo $X
	X=$((X+1))
done