// https://www.hackerrank.com/challenges/c-tutorial-conditional-if-else

#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    int i;
    cin >> i;
    
    if (i == 1) { cout << "one"; }
    else if (i == 2) { cout << "two"; }
    else if (i == 3) { cout << "three"; }
    else if (i == 4) { cout << "four"; }
    else if (i == 5) { cout << "five"; }
    else if (i == 6) { cout << "six"; }
    else if (i == 7) { cout << "seven"; }
    else if (i == 8) { cout << "eight"; }
    else if (i == 9) { cout << "nine"; }
    else { cout << "Greater than 9"; }

    return 0;
}

