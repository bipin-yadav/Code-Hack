# https://www.hackerrank.com/challenges/ruby-infinite-loop

loop do
  coder.practice
  break if coder.oh_one?
end
