# https://www.hackerrank.com/challenges/ruby-tutorials-object-method-parameters

a.range?(b, c)
