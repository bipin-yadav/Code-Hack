# https://www.hackerrank.com/challenges/ruby-hash-initialization

empty_hash = Hash.new 

default_hash = Hash.new
default_hash.default = 1

hackerrank = {"simmy" => 100, "vivmbbs" => 200}
