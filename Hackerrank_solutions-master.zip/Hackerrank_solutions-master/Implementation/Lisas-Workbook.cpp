/*******************************************************
 * Copyright (C) 2016 Haotian Wu
 * 
 * This file is NOT a solution.
 *
 * For the solution to "Lisa's Workbook", see "bear-and-workbook.cpp" in this folder.
 *******************************************************/
