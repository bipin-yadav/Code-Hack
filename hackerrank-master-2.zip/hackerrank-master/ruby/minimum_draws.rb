num_cases = gets.to_i
num_cases.times do
  pairs = gets.to_i
  puts "#{pairs + 1}"
end
