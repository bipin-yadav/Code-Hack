#!/bin/bash

uniq -ci | cut -c7-