____ is a Sun specification for a distributed, shared memory.



1. **JavaSpaces**

2. DCOM

3. DDObjects

4. Jt