____ is a framework for distributed objects using the Python programming language.


1. **Pyro**

2. DCOM

3. DDObjects 

4. Jt