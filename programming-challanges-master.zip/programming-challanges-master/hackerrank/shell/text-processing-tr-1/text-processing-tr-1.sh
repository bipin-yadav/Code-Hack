#!/bin/bash

tr '()' '[]'