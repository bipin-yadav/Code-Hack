#!/bin/bash
sort -k2,2 -t $'\t' -n -r