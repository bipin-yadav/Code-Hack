import math
n = int(raw_input())

print math.factorial(n)