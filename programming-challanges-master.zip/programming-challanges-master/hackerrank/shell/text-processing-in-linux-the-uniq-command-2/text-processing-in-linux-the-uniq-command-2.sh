#!/bin/bash

uniq -c | cut -c7-