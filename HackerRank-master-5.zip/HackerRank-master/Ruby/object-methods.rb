# https://www.hackerrank.com/challenges/ruby-tutorial-object-methods

number.even?
