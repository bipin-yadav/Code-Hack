/*******************************************************
 * Copyright (C) 2015 Haotian Wu
 * 
 * This file is NOT a solution.
 *
 * For the solution to "Max min", see "angry-children.cpp" in this folder.
 *******************************************************/
