# https://www.hackerrank.com/challenges/ruby-tutorial-everything-is-an-object

print self
