The reduce function typically outputs a smaller set than what is input to it.

1. **True**

2. False