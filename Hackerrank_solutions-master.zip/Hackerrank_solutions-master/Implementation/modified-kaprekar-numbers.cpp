/*******************************************************
 * Copyright (C) 2015 Haotian Wu
 * 
 * This file is NOT a solution.
 *
 * For the solution to "Modified Kaprekar Numbers", see "kaprekar-numbers.cpp" in this folder.
 *******************************************************/
