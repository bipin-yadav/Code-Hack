# https://www.hackerrank.com/challenges/ruby-hash-method-each

def iter_hash(hash)
  hash.each do |k,v|
    puts k
    puts v
  end
end
