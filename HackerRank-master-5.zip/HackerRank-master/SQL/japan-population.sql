-- https://www.hackerrank.com/challenges/japan-population

SELECT SUM(Population)
FROM City
WHERE CountryCode = 'JPN';
