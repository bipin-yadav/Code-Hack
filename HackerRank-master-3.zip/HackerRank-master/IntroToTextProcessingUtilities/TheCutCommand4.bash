#!/bin/bash
cut -c1-4