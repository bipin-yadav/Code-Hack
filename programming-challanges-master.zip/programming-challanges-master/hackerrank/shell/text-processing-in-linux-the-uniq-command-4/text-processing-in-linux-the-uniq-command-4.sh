#!/bin/bash

uniq -u