<p align="center">
  <a href="https://www.hackerrank.com/rootulp">
    <img src="https://hackinout.co/static/inout/images/SponsorLogos/logo_hackerrank.svg"
         alt="Hackerrank Logo"
         height="150" width="300">
  </a>
  <br>
  <a href="https://codeclimate.com/github/rootulp/hackerrank">
    <img src="https://img.shields.io/codeclimate/github/rootulp/hackerrank.svg?style=flat-square"
         alt="Code Climate">
  </a>
  <a href="http://rootulp.mit-license.org">
    <img src="http://img.shields.io/:license-mit-blue.svg?style=flat-square"
         alt="License">
  </a>
</p>
