#!/bin/bash

sed -e 's/\bthy\b/{&}/ig'