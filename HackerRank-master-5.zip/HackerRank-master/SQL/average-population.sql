-- https://www.hackerrank.com/challenges/average-population

SELECT cast(AVG(Population) as integer)
FROM City;
