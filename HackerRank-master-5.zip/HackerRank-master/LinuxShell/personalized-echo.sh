#!/bin/bash

# https://www.hackerrank.com/challenges/bash-tutorials---a-personalized-echo

read name
echo "Welcome $name"
