exec"print'%.15f'%sum((-1.)**i/(2*i+1)for i in range(input()));"*input()
