# https://www.hackerrank.com/challenges/ruby-array-index-ii

def neg_pos(arr, index)
  arr[-index]
end

def first_element(arr)
  arr.first
end

def last_element(arr)
  arr.last
end

def first_n(arr, n)
  arr.take(n)
end

def drop_n(arr, n)
  arr.drop(n)
end
