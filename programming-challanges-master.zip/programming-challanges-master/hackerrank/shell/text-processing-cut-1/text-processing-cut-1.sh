#!/bin/bash

cut -c3