#!/bin/bash

grep -wiE "(the|that|then|those)"