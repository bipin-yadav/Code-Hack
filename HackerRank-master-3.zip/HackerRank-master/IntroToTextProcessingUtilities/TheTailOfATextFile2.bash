#!/bin/bash
tail -c 20