Find Digits
===========

Given a number, you have to print how many digits in that number exactly divide that number.

### Input:

The first line contains T (number of test cases) followed by T lines each containing N.

### Constraints:

* 1 <= T <= 15
* N < 10<sup>10</sup>

### Output:

Number of digits in that number exactly divides that number.

### Sample Input:

    1
    12

### Sample Output:

    2
