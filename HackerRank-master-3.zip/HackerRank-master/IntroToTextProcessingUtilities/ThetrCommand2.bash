#!/bin/bash
tr -d '[:lower:]'