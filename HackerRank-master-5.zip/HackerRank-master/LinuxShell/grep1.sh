#!/bin/bash
# https://www.hackerrank.com/challenges/text-processing-in-linux-the-grep-command-1

grep $1 -w 'the'

exit 0
