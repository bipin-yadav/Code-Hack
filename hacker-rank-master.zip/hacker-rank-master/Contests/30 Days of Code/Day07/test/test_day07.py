import pytest
from ..__main__ import day07

def test_case_1():
    assert day07([1,4,3,2]) == [2,3,4,1]
