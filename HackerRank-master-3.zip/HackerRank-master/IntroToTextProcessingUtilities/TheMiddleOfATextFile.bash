#!/bin/bash
sed -n 12,22p