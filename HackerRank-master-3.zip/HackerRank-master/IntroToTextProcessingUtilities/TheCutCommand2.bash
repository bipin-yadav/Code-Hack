#!/bin/bash
cut -c2,7