-- https://www.hackerrank.com/challenges/population-density-difference

SELECT MAX(Population) - MIN(Population) AS DIFFERENCE FROM City;
