#!/bin/bash
cut -c13-