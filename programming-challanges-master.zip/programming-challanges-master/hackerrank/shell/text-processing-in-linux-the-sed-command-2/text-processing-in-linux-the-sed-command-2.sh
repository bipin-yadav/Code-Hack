#!/bin/bash

sed -e 's/\bthy\b/your/ig'