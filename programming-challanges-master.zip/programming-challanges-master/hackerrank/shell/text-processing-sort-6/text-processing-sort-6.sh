#!/bin/bash

sort -n -t$'\t' -k2