#!/bin/bash

read X
read Y

echo $((X + Y))
echo $((X - Y))
echo $((X * Y))
echo $((X / Y))