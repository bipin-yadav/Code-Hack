#!/bin/bash

cut -f1-3