#!/bin/bash

sort -n