# https://www.hackerrank.com/challenges/ruby-array-initialization

array = []
array1 = [nil]
array2 = [10, 10]
