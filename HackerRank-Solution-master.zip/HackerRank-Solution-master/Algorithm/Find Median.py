n = input()
w = raw_input()
w = w.split()
w = map(int,w)
w = sorted(w)
m = w[n/2 ]
print m