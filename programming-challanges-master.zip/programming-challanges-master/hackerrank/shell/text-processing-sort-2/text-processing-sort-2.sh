#!/bin/bash

sort -r