The local operating system on the server machine passes the incoming packets to the:

1. **server stub**

2. client stub

3. client operating system

4. none of the above