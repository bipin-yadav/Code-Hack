#!/bin/bash

cut -c-4