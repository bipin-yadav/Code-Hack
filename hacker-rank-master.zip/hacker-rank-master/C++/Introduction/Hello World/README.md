# Hello, World!

## Problem Statement

Let's start with the mandatory ritual. Print the string "Hello, World!". You can either use printf (preferred for this tutorial) or cout.
```
printf("Hello, World!");
```
## Sample Output
```
Hello, World!
```
