#!/bin/bash

head -c20