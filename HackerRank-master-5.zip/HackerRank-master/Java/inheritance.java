// https://www.hackerrank.com/challenges/java-inheritence

class Arithmetic {
    public int add(int a, int b) {
        return a + b;
    }
}

class Adder extends Arithmetic {

}
