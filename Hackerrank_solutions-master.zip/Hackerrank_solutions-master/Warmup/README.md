#Warmup
This folder contains the solutions to the questions in the warmup subdomain.

Warmup subdomain all questions completed! 6/2/2015

--------UPDATE 6/19/2015---------

Hackerrank rearranged the questions into new domains. Some solutions in this folder may not belong to this domain.
