_____ is a framework for distributed objects on the Microsoft platform.

1. CORBA

2. **DCOM**

3. DDObjects

4. Jt