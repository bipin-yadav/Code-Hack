#!/bin/bash

sed -e 's/\bthe\b/this/'